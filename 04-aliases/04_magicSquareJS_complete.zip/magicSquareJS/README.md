# magicSquareJS

magicSquareJS is a simple JavaScript library and HTML page that generates and validates magic squares.

For more information about magic squares, check out [Wikipedia](https://en.wikipedia.org/wiki/Magic_square).

# LICENSE

magicSquareJS is available under the Apache 2.0 license.

# Maintainers

This project is maintained by teamWYXZ:
- Will
- Yasmin
- Xanthe
- Zack
## Contact Info

For info on this project, please contact [Xanthe](mailto:xanthe@example.com).
