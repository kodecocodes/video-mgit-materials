class Square {
  /**
   * 
   * @param {number} size 
   */
  constructor(size) {
    // TODO
  }

  /**
   * 
   * @param {string} string 
   * @return {Square}
   */
  static fromString(string) {
    // TODO
    return new Square(1);
  }

  /**
   * 
   * @param {number[][]} array 
   * @return {Square}
   */
  static fromArray(array) {
    // TODO
    return new Square(1);
  }

  /**
   * @return {string}
   */
  toString() {
    // TODO
    return "";
  }

  /**
   * @return {bool}
   */
  isMagic() {
    // TODO
    return false;
  }
}

